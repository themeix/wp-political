<?php

namespace PoliticalElementorAddons\Widgets;

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;
use Elementor\Scheme_Typography;
use Elementor\Scheme_Color;
use Elementor\Group_Control_Image_Size;

if (!defined('ABSPATH')) exit; // Exit if accessed directly

/**
 * @since 1.1.0
 */

function campaign_categories()
{

    $terms = get_terms(array(
        'taxonomy' => 'category',
        'hide_empty' => false,
    ));

    $term_name = wp_list_pluck($terms, 'name', 'term_id');

    return $term_name;
}

class PoliticalCampaigns extends Widget_Base
{

    public function get_name()
    {
        return 'p-campaigns';
    }

    public function get_title()
    {
        return __('Campaigns', 'political-core');
    }

    public function get_icon()
    {
        return 'eicon-clock';
    }

    public function get_categories()
    {
        return ['political-addons'];
    }
    protected function _register_controls()
    {

        $this->start_controls_section(
            'campaign_content',
            [
                'label' => __('Campaign', 'political-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
            'title_words_limit',
            [
                'label' => __('Title Words Limit', 'political-core'),
                'type' => \Elementor\Controls_Manager::NUMBER,
                'default' => __('8', 'political-core'),
            ]
        );
        $this->add_control(
            'campaign_per_page',
            [
                'label' => __('Campaign Per Page', 'political-core'),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => __('6', 'political-core'),
                'placeholder' => __('Input campaign per page', 'political-core'),
            ]
        );
        $this->add_control(
            'campaign_order',
            [
                'label' => __('Order', 'political-core'),
                'type' => \Elementor\Controls_Manager::SELECT,
                'options' => [
                    'ASC'  => __('ASC', 'political-core'),
                    'DSC' => __('DSC', 'political-core'),
                ],
                'default' => __('DSC', 'political-core'),
            ]
        );

        $this->add_control(
            'p_campaign_pagination_content',
            [
                'label' => esc_html__('Pagination', 'political-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'campaign_pagination',
            [
                'label' => __('Pagination', 'political-core'),
                'type' => \Elementor\Controls_Manager::SWITCHER,
                'label_on' => __('Show', 'political-core'),
                'label_off' => __('Hide', 'political-core'),
                'return_value' => 'yes',
                'default' => 'yes',
            ]
        );

        $this->add_control(
			'p_pagination_align',
			[
				'label' => esc_html__( 'Pagination Alignment', 'political' ),
				'type' => \Elementor\Controls_Manager::CHOOSE,
				'options' => [
					'left' => [
						'title' => esc_html__( 'Left', 'political' ),
						'icon' => 'fa fa-align-left',
					],
					'center' => [
						'title' => esc_html__( 'Center', 'political' ),
						'icon' => 'fa fa-align-center',
					],
					'right' => [
						'title' => esc_html__( 'Right', 'political' ),
						'icon' => 'fa fa-align-right',
					],
				],
				'default' => 'center',
				'toggle' => true,
			]
		);

        $this->add_control(
			'p_pagination_spacing',
			[
				'label' => __( 'Top Spacing', 'political-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .row.pagination' => 'margin-top: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->end_controls_section();

        //Style Tab
        $this->start_controls_section(
            'campaign_style',
            [
                'label' => __('Style', 'political-core'),
                'tab' => \Elementor\Controls_Manager::TAB_STYLE,
            ]
        );

        $this->add_control(
			'p_campaign_title_title',
			[
				'label' => __( 'Title', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_campain_title_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .campaign-content h4' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_post_title_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .news-content h4 a',
			]
		);

        //location Style
        $this->add_control(
			'p_campaign_location',
			[
				'label' => __( 'Location', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_campaign_location_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .campaign-content > small' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_campaign_location_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .campaign-content > small',
			]
		);
        
        $this->add_control(
			'p_location_spacing',
			[
				'label' => __( 'Icon Spacing', 'political-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .campaign-content > small i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'p_campaign_title_meta_data',
			[
				'label' => __( 'Meta Data', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_campaign_title_metadata_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .campaign-event .campaign-content .meta-data li small' => 'color: {{VALUE}}',
				],
			]
		);
        
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_post_metadata_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .campaign-event .campaign-content .meta-data li small',
			]
		);

        $this->add_control(
			'p_metadata_spacing',
			[
				'label' => __( 'Icon Spacing', 'political-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .campaign-event .campaign-content .meta-data li small i' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

        

        //Pagination style 
        $this->add_control(
            'p_campaign_pagination_style',
            [
                'label' => esc_html__('Pagination', 'political-core'),
                'type' => \Elementor\Controls_Manager::HEADING,
                'separator' => 'before',
            ]
        );

        $this->add_control(
            'p_pagination_color',
            [
                'label' => esc_html__('Color', 'political-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'p_pagination_current_color',
            [
                'label' => esc_html__('Current Page Color', 'political-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers.current' => 'color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'p_pagination_bg_color',
            [
                'label' => esc_html__('Background Color', 'political-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers' => 'background-color: {{VALUE}}',
                ],
            ]
        );
        $this->add_control(
            'p_pagination_bg_current__color',
            [
                'label' => esc_html__('Background Current Color', 'political-core'),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} .pagination .nav-links .page-numbers.current' => 'background-color: {{VALUE}}',
                ],
            ]
        );

        $this->add_group_control(
            Group_Control_Typography::get_type(),
            [
                'name' => 'p_pagination_typography',
                'label' => esc_html__('Typography', 'political-core'),
                'selector' => '{{WRAPPER}} .pagination .nav-links .page-numbers',
            ]
        );


        $this->end_controls_section();

        //Upcoming campaign timer

        $this->start_controls_section(
            'p_upcoming_campaign_timer',
            [
                'label' => __('Campaign Countdown', 'political-core'),
                'tab' => \Elementor\Controls_Manager::TAB_CONTENT,
            ]
        );

        $this->add_control(
			'p_upcoming_campaign_title_title',
			[
				'label' => __( 'Title', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_upcoming_campain_title_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper h4' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_upcoming_post_title_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper h4',
			]
		);

        $this->add_control(
			'p_upcoming_start_campaign_title_title',
			[
				'label' => __( 'Start options', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_upcoming_campain_start_label_color',
			[
				'label' => __( 'Satrt Label Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper small' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_upcoming_start_label_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper small',
			]
		);
        $this->add_control(
			'p_upcoming_campain_start_date_color',
			[
				'label' => __( 'Satrt Date Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper small span' => 'color: {{VALUE}}!important',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_upcoming_start_date_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper small span',
			]
		);

        //metadata Style
        $this->add_control(
			'p_upcoming_campaign_metadata',
			[
				'label' => __( 'Meta Data', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_upcoming_campaign_location_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper .meta-data small' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_upcoming_campaign_location_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper .meta-data small',
			]
		);
        
        $this->add_control(
			'p_upcoming_location_spacing',
			[
				'label' => __( 'Icon Spacing', 'political-core' ),
				'type' => Controls_Manager::SLIDER,
				'size_units' => [ 'px', '%' ],
				'range' => [
					'px' => [
						'min' => 0,
						'max' => 100,
						'step' => 1,
					],
					'%' => [
						'min' => 0,
						'max' => 100,
					],
				],
				'default' => [
					'unit' => '%',
					'size' => 2,
				],
				'selectors' => [
					'{{WRAPPER}} .upcoming-campaign .upcoming-campaign-wrapper .meta-data small' => 'margin-right: {{SIZE}}{{UNIT}};',
				],
			]
		);

        $this->add_control(
			'p_upcoming_campaign_countdown',
			[
				'label' => __( 'Countdown', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_upcoming_coundown_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .countdown li h3' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_upcoming_coundown_color_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .countdown li h3',
			]
		);

        $this->add_control(
			'p_upcoming_campaign_countdown_label',
			[
				'label' => __( 'Countdown Label', 'political' ),
				'type' => \Elementor\Controls_Manager::HEADING,
				'separator' => 'before',
			]
		);
        $this->add_control(
			'p_upcoming_campaign_label_color',
			[
				'label' => __( 'Color', 'political-core' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .countdown li span' => 'color: {{VALUE}}',
				],
			]
		);
        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'name' => 'p_upcoming_campaign_label_typography',
				'label' => __( 'Typography', 'political-core' ),
				'selector' => '{{WRAPPER}} .countdown li span',
			]
		);

       

        
        $this->end_controls_tab();

        $this->end_controls_tabs();

        $this->end_controls_section();
    }

    protected function render()
    {
        $settings = $this->get_settings_for_display();
        $rand_id = rand(654, 65465465);
        $location_info = '';
        $campaign_start = '';
        $campaign_end = '';
        $campaign_date = '';
        $campaign_full_date = '';
        $campaign_end_full_date = '';
        ?>



        <div class="row blog-grid" id="upcomming-events">
            <?php
                    $args = array(
                        'post_type'        => 'campaign',
                        'posts_per_page'   => -1
                    );
                    $posts = get_posts($args);
                    if (!empty($posts)) {
                        $dates = array();
                        $short_time_camp_start = '';
                        foreach ($posts as $field) {
                            if(function_exists('get_field')):
                                $short_time_camp_start = get_field('campaign_start', $field->ID);
                            endif;

                            if (date("Y-m-d H:i:s") <= date("Y-m-d H:i:s", strtotime($short_time_camp_start))) :
                                $dates[] = $short_time_camp_start;
                            endif;
                        }

                        if ($dates) :
                            $upcomming_date = date("F d, Y", strtotime(min($dates)));
                            $upcomming_full_date = date("Y-m-d H:i:s", strtotime(min($dates)));
                            $upcomming_js_date = date("M d, Y H:i:s", strtotime(min($dates)));
                        else :
                            $upcomming_date = '';
                            $upcomming_full_date = '';
                            $upcomming_js_date = '';
                        endif;
                    }

                    echo '<script>';
                    echo '
                        jQuery(document).ready(function($){
                            const campaign = document.querySelector(".upcomming_events");
                            $("#upcomming-events").prepend(campaign);
                            // day counter
                            if ($("#countdown-' . $rand_id . '").length) {
                               const second = 1000,
                                 minute = second * 60,
                                 hour = minute * 60,
                                 day = hour * 24;
                               let birthday = "' . $upcomming_js_date . '",
                                 countDown = new Date(birthday).getTime(),
                                 x = setInterval(function () {
                                   let now = new Date().getTime(),
                                     distance = countDown - now;
                             
                                   (document.getElementById("days-' . $rand_id . '").innerText = Math.floor(distance / day)),
                                     (document.getElementById("hours-' . $rand_id . '").innerText = Math.floor(
                                       (distance % day) / hour
                                     )),
                                     (document.getElementById("minutes-' . $rand_id . '").innerText = Math.floor(
                                       (distance % hour) / minute
                                     )),
                                     (document.getElementById("seconds-' . $rand_id . '").innerText = Math.floor(
                                       (distance % minute) / second
                                     ));
                                   //seconds
                                 }, 0);
                             }
                        });
                        ';
                    echo '</script>';



                    //$x = 0;
                    $campaigns_per_page = $settings['campaign_per_page'];
                    $order = $settings['campaign_order'];
                    // $campaign_style = $settings['campaign_title_style'];
                    // $layout1 = $settings['style_one_layout'];
                    // $layout2 = $settings['style_two_layout'];
                    // $words_limit = $settings['title_words_limit'];

                    $paged = (get_query_var('paged')) ? get_query_var('paged') : 1;
                    if (is_front_page()) {
                        $paged = (get_query_var('page')) ? get_query_var('page') : 1;
                    }


                    $query = new \WP_Query(array(
                        'post_type' => 'campaign',
                        'posts_per_page' => $campaigns_per_page,
                        'order' => "$order",
                        'posts_status' => 'publish',
                        'paged' => $paged

                    ));
                    if ($query->have_posts()) :
                        while ($query->have_posts()) : $query->the_post();
                            if(function_exists('get_field')):
                                $location_info = get_field('campaign_location');
                                $campaign_start = date('h:i:a', strtotime(get_field('campaign_start')));
                                $campaign_end = date('h:i:a', strtotime(get_field('campaign_end')));
                                $campaign_date = date("F d, Y", strtotime(get_field('campaign_start')));
                                $campaign_full_date = date("Y-m-d H:i:s", strtotime(get_field('campaign_start')));
                                $campaign_end_full_date = date('Y-m-d H:i:s', strtotime(get_field('campaign_end')));
                            endif;

                            ?>
                    <div class="col-md-6 <?php if ($campaign_date === $upcomming_date) {
                                                                echo 'upcomming_events';
                                                            } ?>">
                        <?php
                            $up_post_id = '';
                            $class = '';
                            if (has_post_thumbnail()) {
                                $class = 'has_post_thumbnail';
                            }
                            if ($upcomming_full_date === $campaign_full_date && $upcomming_full_date) {
                                $up_post_id = get_the_id();
                                echo '<div class="upcoming-campaign">
                                <div class="upcoming-campaign-wrapper  ">
                                <h4>' . get_the_title() . '</h4>
                                <small>Start: <span class="text-danger fw-bold">' . esc_html($campaign_date) . '</span></small>
                                <ul class="meta-data list-inline  mt-1 ">
                                    <li class="list-inline-item"><small><i class="im im-location"></i>' . esc_html($location_info['location_name']) . '</small></li>
                                    <li class="list-inline-item"><small><i class="im im-clock-o"></i> ' . esc_html($campaign_start) . ' - ' . esc_html($campaign_end) . '</small></li>
                                </ul>
                                <div id="countdown-' . $rand_id . '" class="mt-2 countdown">
                                    <ul class="list-inline">
                                    <li>
                                        <h3 id="days-' . $rand_id . '">0</h3>
                                        <span>days</span>
                                    </li>
                                    <li>
                                        <h3 id="hours-' . $rand_id . '">0</h3>
                                        <span>Hours</span>
                                    </li>
                                    <li>
                                        <h3 id="minutes-' . $rand_id . '">0</h3>
                                        <span>Minutes</span>
                                    </li>
                                    <li>
                                        <h3 id="seconds-' . $rand_id . '">0</h3>
                                        <span>Seconds</span>
                                    </li>
                                    </ul>
                                </div>

                                </div>
                            </div>';
                                        }

                            if ($up_post_id != get_the_id()):
                                echo '<div class="campaign-event">
                                    <div class="feature-image ' . $class . '">
                                        <div class="image-frame ">
                                            <a href="' . get_the_permalink() . '">' . the_post_thumbnail('thumbail', array('class' => 'w-100')) . '</a>
                                        </div>
                                    </div>
                                    <div class="campaign-content">
                                        <h4><a href="' . get_the_permalink() . '" class="text-decoration-none">' . get_the_title() . '</a></h4>';
                                        
                                        if(isset($location_info['location_name'])):
                                            echo '<small><i class="im im-location"></i>' . esc_html($location_info['location_name']) . '</small>';
                                        endif;

                                        echo '<ul class="meta-data list-inline mt-1">
                                            <li class="list-inline-item"><small><i class="im im-calendar"></i>' . esc_html($campaign_date) . '</small></li>
                                            <li class="list-inline-item"><small><i class="im im-clock-o"></i>' . esc_html($campaign_start) . ' - ' . esc_html($campaign_end) . '</small></li>
                                        </ul>
                                    </div>
                                </div>';
                            endif;
                        ?>

                    </div>

            <?php endwhile;

                        $total_pages = $query->max_num_pages;
                        $current_page = max(1, get_query_var('paged'));

                        if (is_front_page()) :
                            $current_page = max(1, get_query_var('page'));
                        endif;
                    endif; ?>

        </div>

<?php if ($settings['campaign_pagination'] == 'yes') :
            echo '<div class="row pagination" style="text-align: ' . $settings['p_pagination_align'] . '!important"> <div class="nav-links col-md-12">';
            echo paginate_links(array(
                'total' => $total_pages,
                'current' => $current_page,
                'prev_text'    => __('prev'),
                'next_text'    => __('next'),
            ));
            echo '<div></div>';
        endif;
    }
}
