<?php

/**
 * @package ThemeixPlugins
 */
/*
Plugin Name: Political Core
Plugin URI: https://themeix.com/plugins/political-core
Description: This is plugin use for Themeix political WordPress theme.
Version: 1.2.0
Author: Themeix
Author URI: https://themeix.com/
License: GPLv2 or later 
Text Domain: political-core
*/

/*
This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

Copyright 2005-2015 Automattic, Inc.
*/

if (!defined('ABSPATH')) {
	die;
}


class ThemeixPoliticalPlugin
{
	function add_action_hook()
	{
		add_action('init', array($this, 'political_post_type'));
		add_shortcode('political_social_share', array($this, 'political_social_sharing_buttons'));
		add_action('show_user_profile', array($this, 'political_extra_user_profile_fields'));
		add_action('edit_user_profile', array($this, 'political_extra_user_profile_fields'));
		add_action('personal_options_update', array($this, 'political_save_extra_user_profile_fields'));
		add_action('edit_user_profile_update', array($this, 'political_save_extra_user_profile_fields'));
	}

	//activation
	function activation()
	{
		//flush rewrite rules
		flush_rewrite_rules();
	}

	//Deactivation
	function deactivation()
	{ }

	/*
* Creating a function to create our CPT
*/

	function political_post_type()
	{
		// Set UI labels for Custom Post Type
		$labels = array(
			'name'                => esc_html__('Campaigns', 'political'),
			'singular_name'       => esc_html__('Campaign', 'political'),
			'menu_name'           => esc_html__('Campaigns', 'political'),
			'parent_item_colon'   => esc_html__('Parent Campaign', 'political'),
			'all_items'           => esc_html__('All Campaigns', 'political'),
			'view_item'           => esc_html__('View Campaign', 'political'),
			'add_new_item'        => esc_html__('Add New Campaign', 'political'),
			'add_new'             => esc_html__('Add New', 'political'),
			'edit_item'           => esc_html__('Edit Campaign', 'political'),
			'update_item'         => esc_html__('Update Campaign', 'political'),
			'search_items'        => esc_html__('Search Campaign', 'political'),
			'not_found'           => esc_html__('Not Found', 'political'),
			'not_found_in_trash'  => esc_html__('Not found in Trash', 'political'),
		);

		// Set other options for Custom Post Type

		$args = array(
			'label'               => esc_html__('Campaigns', 'political'),
			'description'         => esc_html__('Campaign news and reviews', 'political'),
			'labels'              => $labels,
			'supports'            => array('title', 'editor', 'excerpt', 'author', 'thumbnail', 'comments', 'revisions', 'custom-fields',),
			'taxonomies'          => array('genres'),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'show_in_nav_menus'   => true,
			'show_in_admin_bar'   => true,
			'menu_position'       => 5,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'menu_icon'           => 'dashicons-megaphone',
			'capability_type'     => 'post',
			'show_in_rest' => true,

		);

		// Registering your Custom Post Type
		register_post_type('campaign', $args);
	}


	//churel Social Share Buttons
	function political_social_sharing_buttons()
	{
		if (is_singular()) {

			// Get current post URL 
			$Post_url = get_the_permalink();

			// Get current post title
			$post_title = get_the_title();

			// Construct sharing URL without using any script
			$twitterURL = 'https://twitter.com/intent/tweet?text=' . $post_title . '&amp;url=' . $Post_url . '&amp;via=churel';
			$facebookURL = 'https://www.facebook.com/sharer/sharer.php?u=' . $Post_url;
			$googleURL = 'https://plus.google.com/share?url=' . $Post_url;
			$linkedInURL = 'https://www.linkedin.com/shareArticle?mini=true&url=' . $Post_url . '&amp;title=' . $post_title;

			?>

			<ul class="float-end entry-social list-inline m-0">

				<li class="list-inline-item facebook">
					<a class="mt-1" target="_blank" data-toggle="tooltip" data-placement="top" title="" href="<?php echo esc_url($facebookURL); ?>" onclick="window.open(this.href, 'facebook-share','width=580,height=296');return false;" data-original-title="Facebook">
						<i class="im im-facebook"></i>

					</a>
				</li>
				<li class="list-inline-item twitter">
					<a class="mt-1" target="_blank" data-toggle="tooltip" data-placement="top" title="" href="<?php echo esc_url($twitterURL); ?>" onclick="window.open(this.href, 'twitter-share','width=580,height=296');return false;" data-original-title="Twitter">
						<i class="im im-twitter"></i>

					</a>
				</li>
				<li class="list-inline-item linkedin">
					<a class="mt-1" onclick="window.open(this.href, 'linkedin-share','width=580,height=296');return false;" target="_blank" data-toggle="tooltip" data-placement="top" title="" href="<?php echo esc_url($linkedInURL); ?>" data-original-title="LinkedIn">
						<i class="im im-linkedin"></i>
					</a>
				</li>

			</ul>

		<?php


				}
			}

			function political_extra_user_profile_fields($user)
			{ ?>
		<h3><?php echo esc_html__('Extra profile information', 'churel'); ?></h3>
		<table class="form-table">
			<tr>
				<th><label for="facebook"><?php echo esc_html__('Facebook', 'churel'); ?></label></th>
				<td>
					<input type="text" name="facebook" id="facebook" value="<?php echo esc_attr(get_the_author_meta('facebook', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your facebook url.', 'churel'); ?></span>
				</td>
			</tr>
			<tr>
				<th><label for="twitter"><?php echo esc_html__('Twitter', 'churel'); ?></label></th>
				<td>
					<input type="text" name="twitter" id="twitter" value="<?php echo esc_attr(get_the_author_meta('twitter', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your twitter url.', 'churel'); ?></span>
				</td>
			</tr>
			<tr>
				<th><label for="instagram"><?php echo esc_html__('Instagram', 'churel'); ?></label></th>
				<td>
					<input type="text" name="instagram" id="instagram" value="<?php echo esc_attr(get_the_author_meta('instagram', $user->ID)); ?>" class="regular-text" /><br />
					<span class="description"><?php echo esc_html__('Input your instagram url.', 'churel'); ?></span>
				</td>
			</tr>
		</table>
<?php }

	function political_save_extra_user_profile_fields($user_id)
	{
		if (!current_user_can('edit_user', $user_id)) {
			return false;
		}
		update_user_meta($user_id, 'facebook', $_POST['facebook']);
		update_user_meta($user_id, 'twitter', $_POST['twitter']);
		update_user_meta($user_id, 'instagram', $_POST['instagram']);
	}
}
if (class_exists('ThemeixPoliticalPlugin')) {
	$politicalPlugin = new ThemeixPoliticalPlugin();
	$politicalPlugin->add_action_hook();
}


final class PoliticalElementorAddonsPlugin
{

	/**
	 * Plugin Version
	 *
	 * @since 1.0.0
	 * @var string The plugin version.
	 */
	const VERSION = '1.0.0';

	/**
	 * Minimum Elementor Version
	 *
	 * @since 1.2.0
	 * @var string Minimum Elementor version required to run the plugin.
	 */
	const MINIMUM_ELEMENTOR_VERSION = '2.0.0';

	/**
	 * Minimum PHP Version
	 *
	 * @since 1.0.0
	 * @var string Minimum PHP version required to run the plugin.
	 */
	const MINIMUM_PHP_VERSION = '5.4.0';

	/**
	 * Constructor
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function __construct()
	{

		// Load translation
		add_action('init', array($this, 'i18n'));

		// Init Plugin
		add_action('plugins_loaded', array($this, 'init'));
	}

	/**
	 * Load Textdomain
	 *
	 * Load plugin localization files.
	 * Fired by `init` action hook.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function i18n()
	{
		load_plugin_textdomain('political-core');
	}

	/**
	 * Initialize the plugin
	 *
	 * Validates that Elementor is already loaded.
	 * Checks for basic plugin requirements, if one check fail don't continue,
	 * if all check have passed include the plugin class.
	 *
	 * Fired by `plugins_loaded` action hook.
	 *
	 * @since 1.2.0
	 * @access public
	 */
	public function init()
	{

		// Check if Elementor installed and activated
		if (!did_action('elementor/loaded')) {
			add_action('admin_notices', array($this, 'admin_notice_missing_main_plugin'));
			return;
		}

		// Check for required Elementor version
		if (!version_compare(ELEMENTOR_VERSION, self::MINIMUM_ELEMENTOR_VERSION, '>=')) {
			add_action('admin_notices', array($this, 'admin_notice_minimum_elementor_version'));
			return;
		}

		// Check for required PHP version
		if (version_compare(PHP_VERSION, self::MINIMUM_PHP_VERSION, '<')) {
			add_action('admin_notices', array($this, 'admin_notice_minimum_php_version'));
			return;
		}

		// Once we get here, We have passed all validation checks so we can safely include our plugin
		require_once('plugin.php');
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have Elementor installed or activated.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_missing_main_plugin()
	{
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor */
			esc_html__('"%1$s" requires "%2$s" to be installed and activated.', 'political-core'),
			'<strong>' . esc_html__('political Elementor Addons', 'political-core') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'political-core') . '</strong>'
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required Elementor version.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_elementor_version()
	{
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: Elementor 3: Required Elementor version */
			esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'political-core'),
			'<strong>' . esc_html__('Political Elementor Addons', 'political-core') . '</strong>',
			'<strong>' . esc_html__('Elementor', 'political-core') . '</strong>',
			self::MINIMUM_ELEMENTOR_VERSION
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}

	/**
	 * Admin notice
	 *
	 * Warning when the site doesn't have a minimum required PHP version.
	 *
	 * @since 1.0.0
	 * @access public
	 */
	public function admin_notice_minimum_php_version()
	{
		if (isset($_GET['activate'])) {
			unset($_GET['activate']);
		}

		$message = sprintf(
			/* translators: 1: Plugin name 2: PHP 3: Required PHP version */
			esc_html__('"%1$s" requires "%2$s" version %3$s or greater.', 'political-core'),
			'<strong>' . esc_html__('political Elementor Addons', 'political-core') . '</strong>',
			'<strong>' . esc_html__('PHP', 'political-core') . '</strong>',
			self::MINIMUM_PHP_VERSION
		);

		printf('<div class="notice notice-warning is-dismissible"><p>%1$s</p></div>', $message);
	}
}



// Instantiate Elementor_Post_Grid.
new PoliticalElementorAddonsPlugin();



//Activation Hook
register_activation_hook(__FILE__, array($politicalPlugin, 'activation'));

//Deactivation Hook
register_deactivation_hook(__FILE__, array($politicalPlugin, 'deactivation'));
